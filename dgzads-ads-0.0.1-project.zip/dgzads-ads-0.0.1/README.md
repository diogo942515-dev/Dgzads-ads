# dgzads ads — versão 0.0.1


Projeto Android inicial em Kotlin, com interface em português e painel de controle.

## Recursos desta versão
- Painel inicial e controles iniciar/parar (estado local da interface).
- Serviço opcional de acessibilidade para observar texto de tela e detectar palavras comuns em anúncios.
- Protótipo de reconhecimento textual; ainda não há modelo de IA treinado nem detector visual completo.
- Não realiza cliques, não fecha anúncios e não automatiza anúncios com recompensa.

## Compilar
Abra a pasta deste projeto no Android Studio. Use JDK 17 e instale Android SDK Platform 35 e Build Tools compatíveis. Sincronize o Gradle e selecione **Build > Build APK(s)**.

O APK compilado normalmente estará em `app/build/outputs/apk/debug/app-debug.apk`.

## Serviço de acessibilidade
O serviço é declarado no Manifest. A ativação deve ser feita manualmente em Configurações do Android > Acessibilidade > Serviços instalados, quando o app estiver instalado. A versão atual não envia dados para servidores.

## Gerar APK pelo GitHub Actions (sem instalar Android Studio)
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta (incluindo `.github/workflows/build-apk.yml`) para a branch `main`.
2. Abra a aba **Actions** do repositório.
3. Se necessário, selecione **Compilar APK Android** e clique **Run workflow**.
4. Aguarde o workflow ficar verde; abra a execução e baixe o artefato `dgzads-ads-0.0.1-apk`.
5. Extraia o ZIP do artefato para obter `app-debug.apk` e instale no Android.
