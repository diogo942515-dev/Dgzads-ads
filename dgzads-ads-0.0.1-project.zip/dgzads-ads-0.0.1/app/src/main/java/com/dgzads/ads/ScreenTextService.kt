package com.dgzads.ads

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo


/** Prototype accessibility text observer. It reports possible ad-related words only; it does not click. */
class ScreenTextService : AccessibilityService() {
    private val adWords = listOf("anúncio", "publicidade", "patrocinado", "ad", "skip", "pular", "fechar", "close")
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val root = rootInActiveWindow ?: return
        val text = collectText(root).lowercase()
        // Prototype recognition only. Automatic closing/clicking is intentionally not implemented.
        val possibleAd = adWords.any { word -> text.contains(word) }
        if (possibleAd) {
            // Future version: publish a local event to the app UI for classification.
        }
    }
    private fun collectText(node: AccessibilityNodeInfo): String {
        val result = StringBuilder()
        node.text?.let { result.append(it).append(' ') }
        node.contentDescription?.let { result.append(it).append(' ') }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            result.append(collectText(child))
            child.recycle()
        }
        return result.toString()
    }
    override fun onInterrupt() {}
}
