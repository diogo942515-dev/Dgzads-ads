package com.dgzads.ads


import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView


class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var detector: TextView
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 18, 27)
        window.navigationBarColor = Color.rgb(16, 18, 27)
        buildUi()
    }


    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            setBackgroundColor(Color.rgb(16, 18, 27))
        }
        val scroll = android.widget.ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("dgzads ads", 30, Color.rgb(196, 181, 253), true))
        root.addView(text("Central de automação inteligente · versão 0.0.1", 14, Color.LTGRAY))
        spacer(root, 24)
        val statusCard = card(root)
        status = text("●  SISTEMA PRONTO", 17, Color.rgb(134, 239, 172), true)
        statusCard.addView(status)
        statusCard.addView(text("Reconhecimento de anúncios e elementos de tela", 14, Color.LTGRAY))
        spacer(root, 12)
        val detectCard = card(root)
        detectCard.addView(text("RECONHECIMENTO", 13, Color.rgb(167, 139, 250), true))
        detector = text("Nenhuma análise iniciada.\n\nA versão 0.0.1 prepara a interface e os recursos de acessibilidade.", 15, Color.WHITE)
        detectCard.addView(detector)
        spacer(root, 12)
        val start = button("INICIAR RECONHECIMENTO", Color.rgb(86, 64, 142))
        root.addView(start)
        spacer(root, 8)
        val stop = button("PARAR", Color.rgb(54, 58, 70))
        root.addView(stop)
        spacer(root, 16)
        root.addView(text("Recursos", 19, Color.WHITE, true))
        root.addView(text("• Identificação de textos como ‘Pular’, ‘Fechar’ e ‘Anúncio’\n• Detecção assistiva de elementos na tela\n• Painel e controles em português\n• Sem cliques automáticos em anúncios", 14, Color.LTGRAY))
        spacer(root, 16)
        root.addView(text("Esta versão inicial não fecha anúncios automaticamente nem valida anúncios de recompensa. O reconhecimento por acessibilidade requer ativação manual nas configurações do Android.", 12, Color.GRAY))

        start.setOnClickListener {
            running = true
            status.text = "●  RECONHECIMENTO ATIVO"
            status.setTextColor(Color.rgb(96, 165, 250))
            detector.text = "Reconhecimento ativado. Se o serviço de acessibilidade estiver ligado, textos da tela poderão ser analisados para classificar possíveis anúncios."
        }
        stop.setOnClickListener {
            running = false
            status.text = "●  SISTEMA PAUSADO"
            status.setTextColor(Color.rgb(248, 113, 113))
            detector.text = "Reconhecimento pausado."
        }
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 8, 0, 8)
    }
    private fun card(parent: LinearLayout): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 22, 24, 22)
        setBackgroundColor(Color.rgb(26, 29, 42))
        parent.addView(this)
    }
    private fun button(label: String, color: Int): Button = Button(this).apply {
        text = label; setTextColor(Color.WHITE); setBackgroundColor(color); textSize = 14f
        isAllCaps = false
    }
    private fun spacer(parent: LinearLayout, h: Int) { parent.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }) }
}
